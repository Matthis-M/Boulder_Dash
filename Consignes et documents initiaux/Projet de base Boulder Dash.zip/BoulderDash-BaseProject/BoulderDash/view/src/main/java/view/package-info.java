/**
 * Provides all classes for the view component.
 *
 * @author Jean-Aymeric DIET jadiet@cesi.fr
 * @version 1.0
 */
package view;
