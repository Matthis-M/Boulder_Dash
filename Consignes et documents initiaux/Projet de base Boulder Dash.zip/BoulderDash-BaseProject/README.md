# BoulderDash
[![Codacy Badge](https://api.codacy.com/project/badge/Grade/f58b1e1620cc443f9575a385932c7c73)](https://www.codacy.com?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=Jean-Aymeric/BoulderDash&amp;utm_campaign=Badge_Grade)

*Version 1.0*
*Author Jean-Aymeric DIET - jadiet@cesi.fr*

Base project to start BoulderDash software